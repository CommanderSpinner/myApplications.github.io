# shell tool
small shell tool to copy and paste or write shell tools more comfortable
