#include <gtk/gtk.h>
#include "window.h"

int main (int argc, char *argv[])
{
    createWindow(argc, argv);
    return 0;
}
